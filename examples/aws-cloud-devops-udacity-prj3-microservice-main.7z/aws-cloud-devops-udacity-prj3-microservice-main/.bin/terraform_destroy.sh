# Terraform destroy
cd terraform
terraform destroy -auto-approve